module mysql

import sync

// Values for the capabilities flag bitmask used by the MySQL protocol.
// See more on https://dev.mysql.com/doc/dev/mysql-server/latest/group__group__cs__capabilities__flags.html#details
@[flag]
pub enum ConnectionFlag {
	client_long_password                  // (1 <<  0) Use the improved version of Old Password Authentication
	client_found_rows                     // (1 <<  1) Send found rows instead of affected rows in EOF_Packet
	client_long_flag                      // (1 <<  2) Get all column flags
	client_connect_with_db                // (1 <<  3) Database (schema) name can be specified on connect in Handshake Response Packet
	client_no_schema                      // (1 <<  4) DEPRECATED: Don't allow database.table.column
	client_compress                       // (1 <<  5) Compression protocol supported
	client_odbc                           // (1 <<  6) Special handling of ODBC behavior
	client_local_files                    // (1 <<  7) Can use LOAD DATA LOCAL
	client_ignore_space                   // (1 <<  8) Ignore spaces before '('
	client_protocol_41                    // (1 <<  9) New 4.1 protocol
	client_interactive                    // (1 << 10) This is an interactive client
	client_ssl                            // (1 << 11) Use SSL encryption for the session
	client_ignore_sigpipe                 // (1 << 12) Client only flag
	client_transactions                   // (1 << 13) Client knows about transactions
	client_reserved                       // (1 << 14) DEPRECATED: Old flag for 4.1 protocol
	client_reserved2                      // (1 << 15) DEPRECATED: Old flag for 4.1 authentication \ CLIENT_SECURE_CONNECTION
	client_multi_statements               // (1 << 16) Enable/disable multi-stmt support
	client_multi_results                  // (1 << 17) Enable/disable multi-results
	client_ps_multi_results               // (1 << 18) Multi-results and OUT parameters in PS-protocol
	client_plugin_auth                    // (1 << 19) Client supports plugin authentication
	client_connect_attrs                  // (1 << 20) Client supports connection attributes
	client_plugin_auth_lenenc_client_data // (1 << 21) Enable authentication response packet to be larger than 255 bytes
	client_can_handle_expired_passwords   // (1 << 22) Don't close the connection for a user account with expired password
	client_session_track                  // (1 << 23) Capable of handling server state change information
	client_deprecate_eof                  // (1 << 24) Client no longer needs EOF_Packet and will use OK_Packet instead
	client_optional_resultset_metadata    // (1 << 25) The client can handle optional metadata information in the resultset
	client_zstd_compression_algorithm     // (1 << 26) Compression protocol extended to support zstd compression method
	client_query_attributes               // (1 << 27) Support optional extension for query parameters into the COM_QUERY and COM_STMT_EXECUTE packets
	multi_factor_authentication           // (1 << 28) Support Multi factor authentication
	client_capability_extension           // (1 << 29) This flag will be reserved to extend the 32bit capabilities structure to 64bits
	client_ssl_verify_server_cert         // (1 << 30) Verify server certificate
	client_remember_options               // (1 << 31) Don't reset the options after an unsuccessful connect
}

pub enum MySQLTransactionLevel {
	read_uncommitted
	read_committed
	repeatable_read
	serializable
}

struct SQLError {
	MessageError
}

const mysql_no_connection_error_message = 'No connection to a MySQL server, use `connect()` to connect to a database for working with it'
const mysql_thread_init_error_message = 'db.mysql: failed to initialize MySQL thread state'

struct ConnectionState {
mut:
	conn  &C.MYSQL    = unsafe { nil }
	mutex &sync.Mutex = sync.new_mutex()
}

struct MySQLThreadGuard {
mut:
	active bool
}

struct MySQLConnectionGuard {
mut:
	conn   &C.MYSQL         = unsafe { nil }
	state  &ConnectionState = unsafe { nil }
	thread MySQLThreadGuard
}

pub struct DB {
mut:
	conn  &C.MYSQL         = unsafe { nil }
	state &ConnectionState = unsafe { nil }
}

@[params]
pub struct Config {
pub mut:
	host     string = '127.0.0.1'
	port     u32    = 3306
	user     string
	username string
	password string
	dbname   string
	flag     ConnectionFlag

	// ssl_mode controls the SSL/TLS negotiation policy via `MYSQL_OPT_SSL_MODE`.
	// Set it to `.disabled` to connect to servers without TLS support
	// (libmysqlclient 8.x otherwise tries `.preferred`/`.required`, which can
	// fail against servers built without SSL). When left as `.unset`, no
	// `MYSQL_OPT_SSL_MODE` call is made and the libmysqlclient default applies.
	ssl_mode SslMode

	// local_infile enables `LOAD DATA LOCAL INFILE`, which libmysqlclient 8.x
	// disables by default. It sets `MYSQL_OPT_LOCAL_INFILE` before connecting and
	// adds the `.client_local_files` capability flag, since the statement needs
	// both. The server must also allow it (`local_infile=ON`).
	local_infile bool

	// SSL params, only valid when set .client_ssl
	ssl_key    string
	ssl_cert   string
	ssl_ca     string
	ssl_capath string
	ssl_cipher string
}

// connection_user returns the configured username, accepting both `user` and `username`.
pub fn (config Config) connection_user() !string {
	if config.user != '' && config.username != '' && config.user != config.username {
		return error('db.mysql: Config.user and Config.username must match when both are set')
	}
	if config.username != '' {
		return config.username
	}
	return config.user
}

// val returns the value at `index`.
pub fn (row Row) val(index int) string {
	return row.vals[index]
}

// values returns all row values.
pub fn (row Row) values() []string {
	return row.vals.clone()
}

// connect attempts to establish a connection to a MySQL server.
pub fn connect(config Config) !DB {
	mut db := DB{
		conn: C.mysql_init(0)
	}
	username := config.connection_user()!

	if config.ssl_mode != .unset {
		ssl_mode := int(config.ssl_mode)
		db.set_option(C.MYSQL_OPT_SSL_MODE, &ssl_mode)
	}

	connection_flag := db.apply_local_infile(config)

	if config.flag.has(.client_ssl) {
		if config.ssl_key.len > 0 {
			db.set_option(C.MYSQL_OPT_SSL_KEY, config.ssl_key.str)
		}
		if config.ssl_cert.len > 0 {
			db.set_option(C.MYSQL_OPT_SSL_CERT, config.ssl_cert.str)
		}
		if config.ssl_ca.len > 0 {
			db.set_option(C.MYSQL_OPT_SSL_CA, config.ssl_ca.str)
		}
		if config.ssl_capath.len > 0 {
			db.set_option(C.MYSQL_OPT_SSL_CAPATH, config.ssl_capath.str)
		}
		if config.ssl_cipher.len > 0 {
			db.set_option(C.MYSQL_OPT_SSL_CIPHER, config.ssl_cipher.str)
		}
	}

	connection := C.mysql_real_connect(db.conn, config.host.str, username.str, config.password.str,
		config.dbname.str, config.port, 0, connection_flag)

	if isnil(connection) {
		db.throw_mysql_error()!
	}

	// Sets `db.conn` after checking for `null`
	// because `throw_mysql_error` can't extract an error from a `null` connection,
	// and `panic` will be with an empty message.
	db.conn = connection
	db.state = &ConnectionState{
		conn: connection
	}

	return db
}

fn (mut db DB) apply_local_infile(config Config) ConnectionFlag {
	mut connection_flag := config.flag
	if config.local_infile {
		enabled := u32(1)
		db.set_option(C.MYSQL_OPT_LOCAL_INFILE, &enabled)
		connection_flag.set(.client_local_files)
	}
	return connection_flag
}

// query executes the SQL statement pointed to by the string `q`.
// It cannot be used for statements that contain binary data;
// Use `real_query()` instead.
//
// When the connection was opened with `ConnectionFlag.client_multi_statements`
// and `q` contains more than one statement, only the first result set is
// returned; the server queues the remaining statements and they will only
// finish executing as the client drains them with `next_result()`. Use
// `exec_multi()` to run multi-statement queries to completion.
pub fn (db &DB) query(q string) !Result {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_query(guard.conn, charptr(q.str)) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	result := C.mysql_store_result(guard.conn)
	return Result{result}
}

// use_result discards a pending unbuffered result after a low-level query.
// Use query_stream to execute a query and read its unbuffered rows safely.
pub fn (db &DB) use_result() {
	mut guard := db.acquire_connection_guard() or { return }
	result := C.mysql_use_result(guard.conn)
	if result != unsafe { nil } {
		C.mysql_free_result(result)
	}
	drain_remaining_stream_results(guard.conn)
	guard.release()
}

// real_query makes an SQL query and receive the results.
// `real_query()` can be used for statements containing binary data.
// (Binary data may contain the `\0` character, which `query()`
// interprets as the end of the statement string). In addition,
// `real_query()` is faster than `query()`.
//
// When the connection was opened with `ConnectionFlag.client_multi_statements`
// and `q` contains more than one statement, only the first result set is
// returned; the server queues the remaining statements and they will only
// finish executing as the client drains them with `next_result()`. Use
// `exec_multi()` to run multi-statement queries to completion.
pub fn (mut db DB) real_query(q string) !Result {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_real_query(guard.conn, q.str, q.len) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	result := C.mysql_store_result(guard.conn)
	return Result{result}
}

// more_results reports whether more result sets are available from the most
// recently executed multi-statement query (issued with
// `ConnectionFlag.client_multi_statements`). Pair it with `next_result()` to
// drain pending result sets; otherwise the connection is left in a
// "Commands out of sync" state and cannot run further statements.
pub fn (db &DB) more_results() bool {
	mut guard := db.acquire_connection_guard() or { return false }
	defer {
		guard.release()
	}
	return C.mysql_more_results(guard.conn)
}

// next_result advances the connection to the next result set of a
// multi-statement query. It returns `true` if another result set is now
// available (and can be read with `store_result()`/`Result.rows()`), `false`
// if there are no more result sets, and an error if the server reported one.
//
// Any previous result set must be freed (via `Result.free()` or by consuming
// it with `Result.rows()` and then `Result.free()`) before calling
// `next_result()`. The high-level `exec_multi()` handles this automatically.
pub fn (mut db DB) next_result() !bool {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	code := C.mysql_next_result(guard.conn)
	if code == 0 {
		return true
	}
	if code == -1 {
		return false
	}
	throw_mysql_error_for_conn(guard.conn)!
	return false
}

// store_result reads the result of the current statement into a `Result`,
// which the caller is responsible for freeing (via `Result.free()`). This is
// useful in combination with `next_result()` for iterating over result sets
// of a multi-statement query started by `query()` or `real_query()`.
// If the current statement did not produce a result set (e.g. an `INSERT`),
// the returned `Result` has a `nil` inner pointer.
// Returns an error if the server reported one.
pub fn (db &DB) store_result() !Result {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	c_result := C.mysql_store_result(guard.conn)
	if isnil(c_result) && get_errno(guard.conn) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}
	return Result{c_result}
}

// exec_multi executes a multi-statement `query` against the server and
// returns one entry per executed statement, in execution order. Statements
// that produce a result set (e.g. `SELECT`) contribute their rows; statements
// that do not (e.g. `INSERT`, `UPDATE`) contribute an empty `[]Row`.
//
// Use this with connections opened using `ConnectionFlag.client_multi_statements`
// so that the connection is fully drained and remains usable for subsequent
// queries. All intermediate result sets are freed automatically.
pub fn (mut db DB) exec_multi(query string) ![][]Row {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_real_query(guard.conn, query.str, query.len) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}
	mut results := [][]Row{}
	for {
		c_result := C.mysql_store_result(guard.conn)
		if !isnil(c_result) {
			rows := Result{c_result}.rows()
			C.mysql_free_result(c_result)
			results << rows
		} else {
			if get_errno(guard.conn) != 0 {
				throw_mysql_error_for_conn(guard.conn)!
			}
			results << []Row{}
		}
		code := C.mysql_next_result(guard.conn)
		if code == -1 {
			break
		}
		if code > 0 {
			throw_mysql_error_for_conn(guard.conn)!
		}
	}
	return results
}

// select_db causes the database specified by `db` to become
// the default (current) database on the connection specified by mysql.
pub fn (mut db DB) select_db(dbname string) !bool {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_select_db(guard.conn, dbname.str) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	return true
}

// change_user changes the mysql user for the connection.
// Passing an empty string for the `dbname` parameter, resultsg in only changing
// the user and not changing the default database for the connection.
pub fn (mut db DB) change_user(username string, password string, dbname string) !bool {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	mut result := true

	if dbname != '' {
		result = C.mysql_change_user(guard.conn, username.str, password.str, dbname.str)
	} else {
		result = C.mysql_change_user(guard.conn, username.str, password.str, 0)
	}
	if !result {
		throw_mysql_error_for_conn(guard.conn)!
	}

	return result
}

// affected_rows returns the number of rows changed, deleted,
// or inserted by the last statement if it was an `UPDATE`, `DELETE`, or `INSERT`.
pub fn (db &DB) affected_rows() u64 {
	mut guard := db.acquire_connection_guard() or { return 0 }
	defer {
		guard.release()
	}
	return C.mysql_affected_rows(guard.conn)
}

// autocommit turns on/off the auto-committing mode for the connection.
// When it is on, then each query is committed right away.
pub fn (mut db DB) autocommit(mode bool) ! {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	result := C.mysql_autocommit(guard.conn, mode)

	if result != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}
}

// commit commits the current transaction.
pub fn (db &DB) commit() ! {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	result := C.mysql_commit(guard.conn)

	if result != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}
}

@[params]
pub struct MySQLTransactionParam {
	transaction_level MySQLTransactionLevel = .repeatable_read
}

// begin begins a new transaction.
pub fn (db &DB) begin(param MySQLTransactionParam) ! {
	db.check_connection_is_established()!
	db.set_transaction_level(param.transaction_level)!
	result := db.exec_none('START TRANSACTION')
	if result != 0 {
		db.throw_mysql_error()!
	}
}

// set_transaction_level set level for the transaction
pub fn (db &DB) set_transaction_level(level MySQLTransactionLevel) ! {
	db.check_connection_is_established()!
	mut sql_stmt := 'SET TRANSACTION ISOLATION LEVEL '
	match level {
		.read_uncommitted { sql_stmt += 'READ UNCOMMITTED' }
		.read_committed { sql_stmt += 'READ COMMITTED' }
		.repeatable_read { sql_stmt += 'REPEATABLE READ' }
		.serializable { sql_stmt += 'SERIALIZABLE' }
	}

	result := db.exec_none(sql_stmt)
	if result != 0 {
		db.throw_mysql_error()!
	}
}

// rollback rollbacks the current transaction.
pub fn (db &DB) rollback() ! {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	result := C.mysql_rollback(guard.conn)

	if result != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}
}

// rollback_to rollbacks to a specified savepoint.
pub fn (db &DB) rollback_to(savepoint string) ! {
	if !savepoint.is_identifier() {
		return error('savepoint should be a identifier string')
	}
	db.check_connection_is_established()!
	result := db.exec_none('ROLLBACK TO SAVEPOINT ${savepoint}')
	if result != 0 {
		db.throw_mysql_error()!
	}
}

// savepoint create a new savepoint.
pub fn (db &DB) savepoint(savepoint string) ! {
	if !savepoint.is_identifier() {
		return error('savepoint should be a identifier string')
	}
	db.check_connection_is_established()!
	result := db.exec_none('SAVEPOINT ${savepoint}')
	if result != 0 {
		db.throw_mysql_error()!
	}
}

// release_savepoint releases a specified savepoint.
pub fn (db &DB) release_savepoint(savepoint string) ! {
	if !savepoint.is_identifier() {
		return error('savepoint should be a identifier string')
	}
	db.check_connection_is_established()!
	result := db.exec_none('RELEASE SAVEPOINT ${savepoint}')
	if result != 0 {
		db.throw_mysql_error()!
	}
}

// tables returns a list of the names of the tables in the current database,
// that match the simple regular expression specified by the `wildcard` parameter.
// The `wildcard` parameter may contain the wildcard characters `%` or `_`.
// If an empty string is passed, it will return all tables.
// Calling `tables()` is similar to executing query `SHOW TABLES [LIKE wildcard]`.
pub fn (db &DB) tables(wildcard string) ![]string {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	c_mysql_result := C.mysql_list_tables(guard.conn, wildcard.str)
	if isnil(c_mysql_result) {
		throw_mysql_error_for_conn(guard.conn)!
	}

	result := Result{c_mysql_result}
	mut tables := []string{}

	for row in result.rows() {
		tables << row.vals[0]
	}

	return tables
}

// escape_string creates a legal SQL string for use in an SQL statement.
// The `s` argument is encoded to produce an escaped SQL string,
// taking into account the current character set of the connection.
pub fn (db &DB) escape_string(s string) string {
	conn := db.current_conn()
	if isnil(conn) {
		return ''
	}
	mut thread_guard := mysql_thread_guard() or { return '' }
	defer {
		thread_guard.release()
	}
	unsafe {
		to := malloc_noscan(2 * s.len + 1)
		C.mysql_real_escape_string(conn, to, s.str, s.len)
		return to.vstring()
	}
}

// set_option sets extra connect options that affect the behavior of
// a connection. This function may be called multiple times to set several
// options. To retrieve the current values for an option, use `get_option()`.
pub fn (mut db DB) set_option(option_type int, val voidptr) {
	conn := db.current_conn()
	if isnil(conn) {
		return
	}
	mut thread_guard := mysql_thread_guard() or { return }
	defer {
		thread_guard.release()
	}
	C.mysql_options(conn, option_type, val)
}

// get_option returns the value of an option, settable by `set_option`.
// https://dev.mysql.com/doc/c-api/5.7/en/mysql-get-option.html
pub fn (db &DB) get_option(option_type int) !voidptr {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	mysql_option := unsafe { nil }
	if C.mysql_get_option(guard.conn, option_type, &mysql_option) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	return mysql_option
}

// refresh flush the tables or caches, or resets replication server
// information. The connected user must have the `RELOAD` privilege.
pub fn (mut db DB) refresh(options u32) !bool {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_refresh(guard.conn, options) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	return true
}

// reset resets the connection, and clear the session state.
pub fn (mut db DB) reset() ! {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_reset_connection(guard.conn) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}
}

// ping pings a server connection, or tries to reconnect if the connection
// has gone down.
pub fn (mut db DB) ping() !bool {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_ping(guard.conn) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	return true
}

// validate pings a server connection, or tries to reconnect if the connection
// has gone down.
pub fn (mut db DB) validate() !bool {
	return db.ping()!
}

// close closes the connection.
pub fn (mut db DB) close() ! {
	if isnil(db.state) {
		if isnil(db.conn) {
			return
		}
		mut thread_guard := mysql_thread_guard()!
		defer {
			thread_guard.release()
		}
		C.mysql_close(db.conn)
		db.conn = unsafe { nil }
		return
	}
	db.state.mutex.@lock()
	defer {
		db.state.mutex.unlock()
	}
	if isnil(db.state.conn) {
		db.conn = unsafe { nil }
		return
	}
	mut thread_guard := mysql_thread_guard()!
	defer {
		thread_guard.release()
	}
	C.mysql_close(db.state.conn)
	db.state.conn = unsafe { nil }
	db.conn = unsafe { nil }
}

// info returns information about the most recently executed query.
// See more on https://dev.mysql.com/doc/c-api/8.0/en/mysql-info.html
pub fn (db &DB) info() string {
	mut guard := db.acquire_connection_guard() or { return '' }
	defer {
		guard.release()
	}
	return resolve_nil_str(C.mysql_info(guard.conn))
}

// get_host_info returns a string describing the type of connection in use,
// including the server host name.
pub fn (db &DB) get_host_info() string {
	mut guard := db.acquire_connection_guard() or { return '' }
	defer {
		guard.release()
	}
	return unsafe { C.mysql_get_host_info(guard.conn).vstring() }
}

// get_server_info returns a string representing the MySQL server version.
// For example, `8.0.24`.
pub fn (db &DB) get_server_info() string {
	mut guard := db.acquire_connection_guard() or { return '' }
	defer {
		guard.release()
	}
	return unsafe { C.mysql_get_server_info(guard.conn).vstring() }
}

// get_server_version returns an integer, representing the MySQL server
// version. The value has the format `XYYZZ` where `X` is the major version,
// `YY` is the release level (or minor version), and `ZZ` is the sub-version
// within the release level. For example, `8.0.24` is returned as `80024`.
pub fn (db &DB) get_server_version() u64 {
	mut guard := db.acquire_connection_guard() or { return 0 }
	defer {
		guard.release()
	}
	return C.mysql_get_server_version(guard.conn)
}

// dump_debug_info instructs the server to write debugging information
// to the error log. The connected user must have the `SUPER` privilege.
pub fn (mut db DB) dump_debug_info() !bool {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_dump_debug_info(guard.conn) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	return true
}

// get_client_info returns client version information as a string.
pub fn get_client_info() string {
	return unsafe { C.mysql_get_client_info().vstring() }
}

// get_client_version returns the client version information as an integer.
pub fn get_client_version() u64 {
	return C.mysql_get_client_version()
}

// debug does a `DBUG_PUSH` with the given string.
// `debug()` uses the Fred Fish debug library.
// To use this function, you must compile the client library to support debugging.
// See https://dev.mysql.com/doc/c-api/8.0/en/mysql-debug.html
pub fn debug(debug string) {
	C.mysql_debug(debug.str)
}

// exec executes the `query` on the given `db`, and returns an array of all the results, or an error on failure
pub fn (db &DB) exec(query string) ![]Row {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_query(guard.conn, query.str) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	result := C.mysql_store_result(guard.conn)
	if result == unsafe { nil } {
		return []Row{}
	} else {
		return Result{result}.rows()
	}
}

// exec_one executes the `query` on the given `db`, and returns either the first row from the result, if the query was successful, or an error
pub fn (db &DB) exec_one(query string) !Row {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	if C.mysql_query(guard.conn, query.str) != 0 {
		throw_mysql_error_for_conn(guard.conn)!
	}

	result := C.mysql_store_result(guard.conn)

	if result == unsafe { nil } {
		throw_mysql_error_for_conn(guard.conn)!
	}
	row_vals := C.mysql_fetch_row(result)
	num_cols := C.mysql_num_fields(result)

	if row_vals == unsafe { nil } {
		return Row{}
	}

	mut row := Row{}
	for i in 0 .. num_cols {
		if unsafe { row_vals[i] == nil } {
			row.vals << ''
		} else {
			row.vals << mystring(unsafe { &u8(row_vals[i]) })
		}
	}

	return row
}

// exec_none executes the `query` on the given `db`, and returns the integer MySQL result code
// Use it, in case you don't expect any row results, but still want a result code.
// e.g. for queries like these: INSERT INTO ... VALUES (...)
pub fn (db &DB) exec_none(query string) int {
	mut guard := db.acquire_connection_guard() or { return 1 }
	defer {
		guard.release()
	}
	C.mysql_query(guard.conn, query.str)

	return get_errno(guard.conn)
}

// exec_param_many executes the `query` with parameters provided as `?`'s in the query
// It returns either the full result set, or an error on failure
pub fn (db &DB) exec_param_many(query string, params []string) ![]Row {
	result := db.exec_param_many_result(query, params)!
	return result.rows
}

// exec_param_many_result executes the `query` with parameters provided as `?`'s,
// returning rows and their column names.
pub fn (db &DB) exec_param_many_result(query string, params []string) !RowSet {
	stmt := db.prepare(query)!
	defer {
		stmt.close()
	}
	return stmt.execute_result(params)!
}

// exec_param executes the `query` with one parameter provided as an `?` in the query
// It returns either the full result set, or an error on failure
pub fn (db &DB) exec_param(query string, param string) ![]Row {
	return db.exec_param_many(query, [param])!
}

// exec_param2 executes the `query` with two parameters provided as `?` placeholders.
pub fn (db &DB) exec_param2(query string, param string, param2 string) ![]Row {
	return db.exec_param_many(query, [param, param2])!
}

// A StmtHandle is created through prepare, it will be bound
// to one DB connection and will become unusable if the connection
// is closed
pub struct StmtHandle {
	stmt &C.MYSQL_STMT = &C.MYSQL_STMT(unsafe { nil })
	db   DB
}

// prepare takes in a query string, returning a StmtHandle
// that can then be used to execute the query as many times
// as needed, which must be closed manually by the user
// Placeholders are represented by `?`
pub fn (db &DB) prepare(query string) !StmtHandle {
	mut guard := db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	stmt := C.mysql_stmt_init(guard.conn)
	if stmt == unsafe { nil } {
		throw_mysql_error_for_conn(guard.conn)!
	}

	mut code := C.mysql_stmt_prepare(stmt, query.str, query.len)
	if code != 0 {
		throw_mysql_stmt_error(stmt)!
	}

	return StmtHandle{
		stmt: stmt
		db:   DB{
			conn:  db.current_conn()
			state: db.state
		}
	}
}

// execute takes in an array of params that will be bound to the statement,
// followed by it's execution
// Returns an array of Rows, which will be empty if nothing is returned
// from the query, or possibly an error value
pub fn (stmt &StmtHandle) execute(params []string) ![]Row {
	result := stmt.execute_result(params)!
	return result.rows
}

// execute_result executes the statement and returns rows with column names.
pub fn (stmt &StmtHandle) execute_result(params []string) !RowSet {
	mut guard := stmt.db.acquire_connection_guard()!
	defer {
		guard.release()
	}
	mut bind_params := []C.MYSQL_BIND{}
	for param in params {
		bind := C.MYSQL_BIND{
			buffer_type:   mysql_type_string
			buffer:        param.str
			buffer_length: u32(param.len)
			length:        0
			is_null:       0
		}
		bind_params << bind
	}

	mut response := C.mysql_stmt_bind_param(stmt.stmt, unsafe { &C.MYSQL_BIND(bind_params.data) })
	if response == true {
		throw_mysql_stmt_error(stmt.stmt)!
	}

	mut code := C.mysql_stmt_execute(stmt.stmt)
	if code != 0 {
		throw_mysql_stmt_error(stmt.stmt)!
	}

	query_metadata := C.mysql_stmt_result_metadata(stmt.stmt)
	// If the query returns no metadata we have no data to return
	// This happens in insert queries
	if query_metadata == unsafe { nil } {
		return RowSet{}
	}
	metadata := Result{query_metadata}
	names := metadata.field_names()
	defer {
		unsafe { metadata.free() }
	}
	num_cols := C.mysql_num_fields(query_metadata)
	mut length := []C.v_mysql_ulong{len: num_cols}
	mut is_null := []C.v_mysql_bool{len: num_cols}

	mut binds := []C.MYSQL_BIND{}
	for i in 0 .. num_cols {
		bind := C.MYSQL_BIND{
			buffer_type:   mysql_type_string
			buffer:        0
			buffer_length: 0
			length:        unsafe { &length[i] }
			is_null:       unsafe { &is_null[i] }
		}
		binds << bind
	}

	mut rows := []Row{}
	response = C.mysql_stmt_bind_result(stmt.stmt, unsafe { &C.MYSQL_BIND(binds.data) })
	for {
		code = C.mysql_stmt_fetch(stmt.stmt)
		if code == mysql_no_data {
			break
		}
		lengths := length[0..num_cols].clone()
		mut row := Row{}
		for i in 0 .. num_cols {
			l := lengths[i]
			data := unsafe { malloc(l) }
			binds[i].buffer = data
			binds[i].buffer_length = l
			code = C.mysql_stmt_fetch_column(stmt.stmt, unsafe { &binds[i] }, i, 0)
			if is_null[i] != 0 {
				row.vals << ''
			} else {
				row.vals << unsafe { data.vstring() }
			}
		}
		rows << row
	}
	return RowSet{
		names: names
		rows:  rows
	}
}

// close acts on a StmtHandle to close the mysql Stmt
// meaning it is no longer available for use
pub fn (stmt &StmtHandle) close() {
	mut thread_guard := mysql_thread_guard() or { return }
	defer {
		thread_guard.release()
	}
	C.mysql_stmt_close(stmt.stmt)
}

@[inline]
fn (db &DB) throw_mysql_error() ! {
	conn := db.current_conn()
	if isnil(conn) {
		return error(mysql_no_connection_error_message)
	}
	return error_with_code(get_error_msg(conn), get_errno(conn))
}

@[inline]
fn throw_mysql_stmt_error(stmt &C.MYSQL_STMT) ! {
	return error_with_code(get_stmt_error_msg(stmt), get_stmt_errno(stmt))
}

@[inline]
fn throw_mysql_error_for_conn(conn &C.MYSQL) ! {
	return error_with_code(get_error_msg(conn), get_errno(conn))
}

@[inline]
fn mysql_thread_guard() !MySQLThreadGuard {
	if C.mysql_thread_init() {
		return error(mysql_thread_init_error_message)
	}
	return MySQLThreadGuard{
		active: true
	}
}

@[inline]
fn (mut guard MySQLThreadGuard) release() {
	if guard.active {
		C.mysql_thread_end()
		guard.active = false
	}
}

@[inline]
fn (db &DB) current_conn() &C.MYSQL {
	if !isnil(db.state) {
		return db.state.conn
	}
	return db.conn
}

fn (db &DB) acquire_connection_guard() !MySQLConnectionGuard {
	if !isnil(db.state) {
		db.state.mutex.@lock()
		conn := db.state.conn
		if isnil(conn) {
			db.state.mutex.unlock()
			return error(mysql_no_connection_error_message)
		}
		mut thread_guard := mysql_thread_guard() or {
			db.state.mutex.unlock()
			return err
		}
		return MySQLConnectionGuard{
			conn:   conn
			state:  db.state
			thread: thread_guard
		}
	}
	if isnil(db.conn) {
		return error(mysql_no_connection_error_message)
	}
	mut thread_guard := mysql_thread_guard()!
	return MySQLConnectionGuard{
		conn:   db.conn
		thread: thread_guard
	}
}

@[inline]
fn (mut guard MySQLConnectionGuard) release() {
	guard.thread.release()
	if !isnil(guard.state) {
		guard.state.mutex.unlock()
	}
}

@[inline]
fn (db &DB) check_connection_is_established() ! {
	if isnil(db.current_conn()) {
		return error(mysql_no_connection_error_message)
	}
}

// This module defines the Context type, which carries deadlines, cancellation signals,
// and other request-scoped values across API boundaries and between processes.
// Based on:   https://github.com/golang/go/tree/master/src/context
// Last commit: https://github.com/golang/go/commit/52bf14e0e8bdcd73f1ddfb0c4a1d0200097d3ba2
module context

import rand
import sync
import time

pub type CancelFn = fn ()

pub interface Canceler {
	id string
mut:
	cancel(remove_from_parent bool, err IError)
	done() chan int
}

// A CancelContext can be canceled. When canceled, it also cancels any children
// that implement Canceler.
pub struct CancelContext {
	id string
mut:
	context  Context
	mutex    &sync.Mutex = sync.new_mutex()
	done     chan int
	children map[string]Canceler
	err      IError = none
}

// with_cancel returns a copy of parent with a new done channel. The returned
// context's done channel is closed when the returned cancel function is called
// or when the parent context's done channel is closed, whichever happens first.
//
// Canceling this context releases resources associated with it, so code should
// call cancel as soon as the operations running in this Context complete.
pub fn with_cancel(mut parent Context) (Context, CancelFn) {
	mut c := new_cancel_context(parent)
	propagate_cancel(mut parent, mut c)
	cancel_fn := fn [mut c] () {
		c.cancel(true, canceled)
	}
	return Context(c), CancelFn(cancel_fn)
}

// new_cancel_context returns an initialized CancelContext.
fn new_cancel_context(parent Context) &CancelContext {
	return &CancelContext{
		id:      rand.uuid_v4()
		context: parent
		mutex:   sync.new_mutex()
		done:    chan int{cap: 2}
		err:     none
	}
}

// deadline always returns none for a CancelContext, since it has no deadline.
pub fn (ctx &CancelContext) deadline() ?time.Time {
	return none
}

// done returns the done channel, which is closed when this context is canceled.
pub fn (mut ctx CancelContext) done() chan int {
	ctx.mutex.lock()
	done := ctx.done
	ctx.mutex.unlock()
	return done
}

// err returns `canceled` after the context has been canceled, or `none` if not yet canceled.
pub fn (mut ctx CancelContext) err() IError {
	ctx.mutex.lock()
	err := ctx.err
	ctx.mutex.unlock()
	return err
}

// value returns the CancelContext itself if the key matches the cancel context key,
// otherwise delegates to the parent context.
pub fn (ctx &CancelContext) value(key Key) ?Any {
	if key == cancel_context_key {
		return ctx
	}
	return ctx.context.value(key)
}

// str returns a string representation of the CancelContext,
// showing the parent context name suffixed with '.with_cancel'.
pub fn (ctx &CancelContext) str() string {
	return context_name(ctx.context) + '.with_cancel'
}

fn (mut ctx CancelContext) cancel(remove_from_parent bool, err IError) {
	if err is none {
		panic('context: internal error: missing cancel error')
	}

	ctx.mutex.lock()
	if ctx.err !is none {
		ctx.mutex.unlock()
		// already canceled
		return
	}

	ctx.err = err

	if !ctx.done.closed {
		ctx.done <- 0
		ctx.done.close()
	}

	for _, child in ctx.children {
		// NOTE: acquiring the child's lock while holding parent's lock.
		mut c := child
		c.cancel(false, err)
	}

	ctx.children = map[string]Canceler{}
	ctx.mutex.unlock()

	if remove_from_parent {
		mut cc := &ctx.context
		remove_child(mut cc, ctx)
	}
}

fn propagate_cancel(mut parent Context, mut child Canceler) {
	done := parent.done()
	select {
		_ := <-done {
			// parent is already canceled
			child.cancel(false, parent.err())
			return
		}
		else {
		}
	}
	mut p := parent_cancel_context(mut parent) or {
		// Pre-extract the parent done channel and pass it by value into the
		// spawn. The goroutine may outlive the caller's stack frame, so
		// dereferencing `parent` inside the spawn (e.g. via parent.done())
		// reads freed stack memory once the caller returns and reuses that
		// region — observed as a consistent segfault in vlib/context/cause_test.v
		// on Linux x86_64. Mirrors the fix in onecontext.run_two_contexts.
		spawn fn (pdone chan int, mut parent Context, mut child Canceler) {
			select {
				_ := <-pdone {
					child.cancel(false, parent.err())
				}
			}
		}(done, mut parent, mut child)
		return
	}

	if p.err is none {
		p.children[child.id] = child
	} else {
		// parent has already been canceled
		child.cancel(false, p.err)
	}
}

// parent_cancel_context returns the underlying CancelContext for parent.
// It does this by looking up parent.value(&cancel_context_key) to find
// the innermost enclosing CancelContext and then checking whether
// parent.done() matches that CancelContext. (If not, the CancelContext
// has been wrapped in a custom implementation providing a
// different done channel, in which case we should not bypass it.)
fn parent_cancel_context(mut parent Context) ?&CancelContext {
	done := parent.done()
	if done.closed {
		return none
	}
	mut p := parent.value(cancel_context_key)?
	match mut p {
		CancelContext {
			pdone := p.done()
			if done == pdone {
				return p
			}
		}
		else {}
	}

	return none
}

// remove_child removes a context from its parent.
fn remove_child(mut parent Context, child Canceler) {
	mut p := parent_cancel_context(mut parent) or { return }
	p.children.delete(child.id)
}

@[has_globals]
module builtin

$if openbsd {
	// OpenBSD lacks the sysctl path lookup that bundled libbacktrace needs,
	// so `-d use_libbacktrace` falls back to the native BSD backtrace path.
	fn print_libbacktrace(frames_to_skip int) {
	}

	@[noinline]
	fn eprint_libbacktrace(frames_to_skip int) {
	}
} $else $if !tinyc {

	// full libbacktrace implementation for gcc/clang (TCC can't compile libbacktrace's C code)
	#flag -I@VEXEROOT/thirdparty/libbacktrace
	#flag @VEXEROOT/thirdparty/libbacktrace/backtrace.o
	#include <backtrace.h>

	// NOTE: Don't mark this as a @[typedef] or it may cause compiler errors!
	pub struct C.backtrace_state {
		// filename &char
	}

	type BacktraceErrorCallback = fn (data voidptr, const_msg &char, errnum i32)

	type BacktraceFullCallback = fn (data voidptr, pc usize, const_filename &char, lineno i32, const_func &char) i32

	fn C.backtrace_create_state(filename &char, threaded i32, error_callback BacktraceErrorCallback, data voidptr) &C.backtrace_state
	fn C.backtrace_full(state &C.backtrace_state, skip i32, cb BacktraceFullCallback, err_cb BacktraceErrorCallback,
		data voidptr) i32

	__global bt_state = init_bt_state()

	fn init_bt_state() &C.backtrace_state {
		mut filename := &char(unsafe { nil })
		$if windows {
			filename = unsafe { string_from_wide(&&u16(g_main_argv)[0]).str }
		} $else {
			filename = unsafe { &&char(g_main_argv)[0] }
		}
		return C.backtrace_create_state(filename, 1, bt_error_handler, 0)
	}

	// for bt_error_callback
	struct BacktraceOptions {
		stdin bool = true
	}

	fn bt_print_callback(data_ptr voidptr, pc usize, filename_ptr &char, line i32, fn_name_ptr &char) i32 {
		data := unsafe { &BacktraceOptions(data_ptr) }
		filename := if filename_ptr == unsafe { nil } {
			'???'
		} else {
			unsafe { filename_ptr.vstring() }
		}
		fn_name := if fn_name_ptr == unsafe { nil } {
			'???'
		} else {
			demangle_v_symbol(unsafe { fn_name_ptr.vstring() })
		}
		// keep it for later
		// pc_64 := u64(pc)
		bt_str := '${filename}:${line}: by ${fn_name}'
		if data.stdin {
			println(bt_str)
		} else {
			eprintln(bt_str)
		}
		return 0
	}

	fn bt_error_callback(data voidptr, msg_ptr &char, errnum i32) {
		// if data != unsafe { nil } && data.state != unsafe { nil } && data.state.filename != unsafe { nil } {
		// 	filename := unsafe{ data.state.filename.vstring() }
		// 	eprint('${filename}: ')
		// }

		msg := unsafe { msg_ptr.vstring() }
		eprint('libbacktrace: ${msg}')
		if errnum > 0 {
			eprint(': ${C.strerror(errnum)}')
		}

		eprintln('')
	}

	// for backtrace_create_state only
	fn bt_error_handler(data voidptr, msg &char, errnum i32) {
		eprint('libbacktrace: ')
		eprint(unsafe { msg.vstring() })
		if errnum > 0 {
			eprint(': ${C.strerror(errnum)}')
		}
		eprintln('')
		exit(1)
	}

	@[noinline]
	fn print_libbacktrace(frames_to_skip int) {
		$if no_backtrace ? {
			return
		}
		data := &BacktraceOptions{}
		C.backtrace_full(bt_state, frames_to_skip, bt_print_callback, bt_error_callback, data)
	}

	@[noinline]
	fn eprint_libbacktrace(frames_to_skip int) {
		$if no_backtrace ? {
			return
		}
		data := &BacktraceOptions{
			stdin: false
		}
		C.backtrace_full(bt_state, frames_to_skip, bt_print_callback, bt_error_callback, data)
	}
} $else {

	// no-op stubs for TCC (TCC can't compile libbacktrace's C code, and
	// it has its own built-in backtrace via tcc_backtrace instead)
	fn print_libbacktrace(frames_to_skip int) {
	}

	@[noinline]
	fn eprint_libbacktrace(frames_to_skip int) {
	}
}
